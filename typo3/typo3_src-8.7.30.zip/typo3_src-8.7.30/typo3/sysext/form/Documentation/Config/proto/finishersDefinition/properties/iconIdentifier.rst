An icon identifier which must be registered through the ``\TYPO3\CMS\Core\Imaging\IconRegistry``.
This icon will be shown within the - :ref:`"Inspector [CollectionElementHeaderEditor]"<typo3.cms.form.prototypes.\<prototypeidentifier>.formelementsdefinition.\<formelementtypeidentifier>.formeditor.editors.*.collectionelementheadereditor>` if the finisher is selected.
