<?php
return [
    'TYPO3\\CMS\\Extbase\\Service\\TypoScriptService' => \TYPO3\CMS\Core\TypoScript\TypoScriptService::class
];
