<?php
return [
    'TYPO3\\CMS\\Frontend\\View\\AdminPanelView' => \TYPO3\CMS\Adminpanel\View\AdminPanelView::class,
    'TYPO3\\CMS\\Frontend\\View\\AdminPanelViewHookInterface' => \TYPO3\CMS\Adminpanel\View\AdminPanelViewHookInterface::class
];
